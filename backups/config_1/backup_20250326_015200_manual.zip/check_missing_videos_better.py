import csv
import re
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler("url_comparison.log"),
        logging.StreamHandler()
    ]
)

# Constants
COLUMN_URL = 'url'
COLUMN_TITLE = 'title'
COLUMN_DURATION_PRE = 'duration_minutes'
COLUMN_DURATION_POST = 'duration'
CSV_HEADERS = ['Video ID', 'URL Originale', 'Titolo', 'Durata']

def normalize_youtube_url(url: Optional[str]) -> Optional[str]:
    """
    Normalizes YouTube URLs to extract video IDs.
    Handles various URL formats including parameters and shortened URLs.
    """
    if not url:
        return None
    
    patterns = [
        r"(?:https?://)?(?:www\.)?(?:"
        r"youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/v/"
        r")([\w-]{11})(?:&|/|$)",
        r"(?:https?://)?(?:www\.)?youtube\.com/watch/.+v=([\w-]{11})"
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url, re.IGNORECASE)
        if match:
            return match.group(1)
    
    return None

def load_urls(file_path: Path, duration_column: str) -> Dict[str, Dict]:
    """Generic function to load URLs from CSV files"""
    urls = {}
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            
            # Validate required columns
            required_columns = {COLUMN_URL, COLUMN_TITLE, duration_column}
            if not required_columns.issubset(reader.fieldnames):
                missing = required_columns - set(reader.fieldnames)
                logging.error(f"Missing columns in {file_path}: {', '.join(missing)}")
                return urls
            
            for row in reader:
                video_id = normalize_youtube_url(row[COLUMN_URL])
                if video_id:
                    urls[video_id] = {
                        'url': row[COLUMN_URL],
                        'title': row[COLUMN_TITLE],
                        'duration': row[duration_column]
                    }
        return urls
    except Exception as e:
        logging.error(f"Error reading {file_path}: {str(e)}", exc_info=True)
        return {}

def compare_files(
    pre_file: Path,
    post_file: Path,
    output_file: Path = Path("missing_videos.csv")
) -> None:
    """Compares pre and post processing files to identify missing videos"""
    logging.info("Starting file comparison...")
    
    pre_urls = load_urls(pre_file, COLUMN_DURATION_PRE)
    post_urls = load_urls(post_file, COLUMN_DURATION_POST)
    
    if not pre_urls:
        logging.error("No valid URLs found in pre-processing file")
        return
    if not post_urls:
        logging.error("No valid URLs found in post-processing file")
        return
    
    missing_videos = {
        vid: info for vid, info in pre_urls.items()
        if vid not in post_urls
    }
    
    # Generate report
    if missing_videos:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
            writer.writeheader()
            for vid, info in missing_videos.items():
                writer.writerow({
                    'Video ID': vid,
                    'URL Originale': info['url'],
                    'Titolo': info['title'],
                    'Durata': info['duration']
                })
    
    # Display summary
    logging.info(f"\nComparison Summary:\n"
                 f"Pre-processing videos: {len(pre_urls)}\n"
                 f"Post-processing videos: {len(post_urls)}\n"
                 f"Missing videos: {len(missing_videos)}")
    
    if missing_videos:
        logging.info(f"Missing videos saved to: {output_file}")
        for i, (vid, info) in enumerate(list(missing_videos.items())[:5], 1):
            logging.info(f"{i}. {info['title']} - {info['url']}")
    else:
        logging.info("All videos from pre-processing exist in post-processing!")

def main() -> None:
    try:
        pre_path = Path("youtube_videos_pre.csv")
        post_path = Path("youtube_videos_post.csv")
        
        if not pre_path.exists():
            raise FileNotFoundError(f"{pre_path} not found")
        if not post_path.exists():
            raise FileNotFoundError(f"{post_path} not found")
            
        compare_files(pre_path, post_path)
        
    except Exception as e:
        logging.error(f"Operation failed: {str(e)}", exc_info=True)

if __name__ == "__main__":
    main()