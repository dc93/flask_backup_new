import csv
import re
from pathlib import Path
from datetime import datetime

def normalize_youtube_url(url):
    """
    Normalizza un URL di YouTube per garantire confronti coerenti.
    Estrae e restituisce solo l'ID del video.
    """
    if not url:
        return None
        
    # Pattern per estrarre l'ID del video YouTube
    patterns = [
        r'(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/v/)([a-zA-Z0-9_-]+)',
        r'youtube\.com/watch/v=([a-zA-Z0-9_-]+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return None

def create_log(message, log_file="url_comparison.log"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_file, "a", encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")

def load_pre_urls(file_path):
    """Carica gli URL dal file pre-elaborazione."""
    urls = {}
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:  # Usa utf-8-sig per gestire il BOM
            reader = csv.DictReader(f)
            for row in reader:
                url = row['url']
                title = row['title']  # Ora dovrebbe funzionare correttamente
                video_id = normalize_youtube_url(url)
                if video_id:
                    urls[video_id] = {
                        'url': url,
                        'title': title,
                        'duration': row.get('duration_minutes', 'N/A')
                    }
        return urls
    except Exception as e:
        print(f"Errore nel leggere il file pre: {str(e)}")
        return {}

def load_post_urls(file_path):
    """Carica gli URL dal file post-elaborazione."""
    urls = {}
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:  # Usa utf-8-sig anche qui per coerenza
            reader = csv.DictReader(f)
            for row in reader:
                url = row['url']
                video_id = normalize_youtube_url(url)
                if video_id:
                    urls[video_id] = {
                        'url': url,
                        'title': row['title'],
                        'duration': row['duration']
                    }
        return urls
    except Exception as e:
        print(f"Errore nel leggere il file post: {str(e)}")
        return {}

def compare_files(pre_file, post_file, output_file="missing_videos.csv"):
    """
    Confronta i file pre e post elaborazione per trovare video mancanti.
    """
    print("Iniziando il confronto dei file...")
    create_log("Inizio confronto")
    
    pre_urls = load_pre_urls(pre_file)
    post_urls = load_post_urls(post_file)
    
    if not pre_urls:
        message = "Nessun URL trovato nel file pre-elaborazione"
        print(message)
        create_log(message)
        return
    if not post_urls:
        message = "Nessun URL trovato nel file post-elaborazione"
        print(message)
        create_log(message)
        return
    
    # Trova i video mancanti
    missing_videos = {}
    for video_id, info in pre_urls.items():
        if video_id not in post_urls:
            missing_videos[video_id] = info
    
    # Crea il report
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Video ID', 'URL Originale', 'Titolo', 'Durata'])
        
        for video_id, info in missing_videos.items():
            writer.writerow([
                video_id,
                info['url'],
                info['title'],
                info['duration']
            ])
    
    # Stampa il resoconto
    print("\nRisultati del confronto:")
    print(f"Video totali nel file pre-elaborazione: {len(pre_urls)}")
    print(f"Video totali nel file post-elaborazione: {len(post_urls)}")
    print(f"Video mancanti nel file post-elaborazione: {len(missing_videos)}")
    
    if missing_videos:
        print(f"\nI video mancanti sono stati salvati in: {output_file}")
        print("\nPrimi 5 video mancanti:")
        for i, (video_id, info) in enumerate(list(missing_videos.items())[:5]):
            print(f"{i+1}. {info['title']} - {info['url']}")
    else:
        print("\nTutti i video del file pre-elaborazione sono presenti nel file post-elaborazione!")
    
    create_log(f"Confronto completato. {len(missing_videos)} video mancanti trovati.")

def main():
    try:
        pre_file = "youtube_videos_pre.csv"
        post_file = "youtube_videos_post.csv"
        
        if not Path(pre_file).exists():
            print(f"Errore: Il file {pre_file} non esiste")
            return
        if not Path(post_file).exists():
            print(f"Errore: Il file {post_file} non esiste")
            return
            
        compare_files(pre_file, post_file)
        
    except Exception as e:
        message = f"Errore generale: {str(e)}"
        print(message)
        create_log(message)

if __name__ == "__main__":
    main()